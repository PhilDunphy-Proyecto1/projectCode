-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-10-2018 a las 20:52:06
-- Versión del servidor: 10.1.36-MariaDB
-- Versión de PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_rec_emp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_empleado`
--

CREATE TABLE `tbl_empleado` (
  `Empleado_ID` int(11) NOT NULL,
  `Empleado_Nombre` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Empleado_Apellido` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Empleado_UserName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Empleado_Password` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Empleado_AccessLevel` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tbl_empleado`
--

INSERT INTO `tbl_empleado` (`Empleado_ID`, `Empleado_Nombre`, `Empleado_Apellido`, `Empleado_UserName`, `Empleado_Password`, `Empleado_AccessLevel`) VALUES
(1, 'usuario1', 'unknown', 'user1', '1234', 'user'),
(2, 'usuario2', 'unknown', 'user2', '1234', 'user'),
(3, 'usuario3', 'unknown', 'user3', '1234', 'user'),
(4, 'Erix', 'Mamani Villacresis', 'erixmv', '1234', 'admin'),
(5, 'Joel', 'Moreno Hidalgo', 'joelmh', '1234', 'admin'),
(6, 'Alejandro', 'Reñones Farré', 'alejandrorf', '1234', 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_incidencia`
--

CREATE TABLE `tbl_incidencia` (
  `Incidencia_ID` int(11) NOT NULL,
  `Incidencia_Titulo` varchar(50) NOT NULL,
  `Incidencia_Descripcion` text NOT NULL,
  `Incidencia_Grado` varchar(20) NOT NULL,
  `Incidencia_Estado` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_incidencia`
--

INSERT INTO `tbl_incidencia` (`Incidencia_ID`, `Incidencia_Titulo`, `Incidencia_Descripcion`, `Incidencia_Grado`, `Incidencia_Estado`) VALUES
(1, 'Teléfono móvil 1 estropeado', 'Buenas tardes,\r\n\r\nMe gustaría informar sobre el mal funcionamiento del teléfono móvil 1.\r\n\r\nÉste se queda colgado muy seguido y no puedo darle el uso que debería.\r\n\r\nEspero que puedan solucionarlo.', 'Medio', 'Resuelta'),
(2, 'Ordenador portátil 1 roto', 'Buenas tardes,\r\n\r\nLes escribo para informar de que el ordenador portátil uno tiene una brecha en la pantalla.\r\n\r\nÉste no se enciende, siniestro total.\r\n', 'Crítico', 'Resuelta'),
(3, 'Sala Multidisciplinar 1 sucia', 'Buenas tardes, \r\n\r\nMe gustaría informar que la sala multidisciplinar 1 está suicia de algún taller que se ha realizado anteriormente.\r\n\r\nNos gustaría poder acceder a la sala ya que tenemos una reuinión en 2 horas y media.\r\n\r\nGracias de antemano.\r\n\r\n', 'Medio', 'En transcurso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_recurso`
--

CREATE TABLE `tbl_recurso` (
  `Recurso_ID` int(11) NOT NULL,
  `Recurso_Nombre` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Recurso_Tipo` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Recurso_Img` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Recurso_Estado` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tbl_recurso`
--

INSERT INTO `tbl_recurso` (`Recurso_ID`, `Recurso_Nombre`, `Recurso_Tipo`, `Recurso_Img`, `Recurso_Estado`) VALUES
(1, 'Sala Multidisciplinar 1', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/multi.png?raw=true', 'Disponible'),
(2, 'Sala Multidisciplinar 2', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/multi.png?raw=true', 'Disponible'),
(3, 'Sala Multidisciplinar 3', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/multi.png?raw=true', 'Disponible'),
(4, 'Sala Multidisciplinar 4', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/multi.png?raw=true', 'Disponible'),
(5, 'Sala de informática 1', 'Sala', 'https://raw.githubusercontent.com/PhilDunphy-Proyecto1/projectCode/master/img/ordenador.png', 'Disponible'),
(6, 'Sala de informática 2', 'Sala', 'https://raw.githubusercontent.com/PhilDunphy-Proyecto1/projectCode/master/img/ordenador.png', 'Disponible'),
(7, 'Taller de cocina', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/cocina.png?raw=true', 'Disponible'),
(8, 'Despacho de entrevistas 1', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/entrevista.png?raw=true', 'Disponible'),
(9, 'Despacho de entrevistas 2', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/entrevista.png?raw=true', 'Disponible'),
(10, 'Sala de actos 1', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/actos.jpg?raw=true', 'Disponible'),
(11, 'Sala de reuniones', 'Sala', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/reunion.png?raw=true', 'Disponible'),
(12, 'Proyector portátil 1', 'Material', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/proyector.png?raw=true', 'Disponible'),
(13, 'Proyector portátil 2', 'Material', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/proyector.png?raw=true', 'Disponible'),
(14, 'Ordenador portátil 1', 'Material', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/portatil.jpg?raw=true', 'Disponible'),
(15, 'Ordenador portátil 2', 'Material', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/portatil.jpg?raw=true', 'Disponible'),
(16, 'Ordenador portátil 3', 'Material', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/portatil.jpg?raw=true', 'Disponible'),
(17, 'Teléfono móvil 1', 'Material', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/movil.png?raw=true', 'Disponible'),
(18, 'Teléfono móvil 2', 'Material', 'https://github.com/PhilDunphy-Proyecto1/projectCode/blob/master/img/movil.png?raw=true', 'Disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_reserva`
--

CREATE TABLE `tbl_reserva` (
  `Reserva_ID` int(11) NOT NULL,
  `Reserva_FechaRec` date DEFAULT NULL,
  `Reserva_HoraRec` time DEFAULT NULL,
  `Reserva_Estado` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Reserva_HoraDev` time DEFAULT NULL,
  `Reserva_FechaDev` date DEFAULT NULL,
  `Empleado_ID` int(11) DEFAULT NULL,
  `Recurso_ID` int(11) DEFAULT NULL,
  `Incidencia_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tbl_reserva`
--

INSERT INTO `tbl_reserva` (`Reserva_ID`, `Reserva_FechaRec`, `Reserva_HoraRec`, `Reserva_Estado`, `Reserva_HoraDev`, `Reserva_FechaDev`, `Empleado_ID`, `Recurso_ID`, `Incidencia_ID`) VALUES
(1, '2018-10-25', '09:20:08', 'Terminado', '09:21:10', '2018-10-25', 1, 7, NULL),
(39, '2018-10-30', '19:55:50', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(40, '2018-10-30', '19:55:59', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(41, '2018-10-30', '19:56:50', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(42, '2018-10-30', '20:00:51', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(43, '2018-10-30', '20:01:12', 'Terminado', '20:01:14', '2018-10-30', 6, 6, NULL),
(44, '2018-10-30', '20:03:47', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(45, '2018-10-30', '20:05:53', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(46, '2018-10-30', '20:06:12', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(47, '2018-10-30', '20:06:29', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(48, '2018-10-30', '20:06:35', 'Terminado', '20:10:26', '2018-10-30', 4, 1, NULL),
(49, '2018-10-30', '20:06:38', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(50, '2018-10-30', '20:06:45', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(51, '2018-10-30', '20:07:10', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(52, '2018-10-30', '20:07:18', 'Terminado', '20:10:26', '2018-10-30', 6, 1, NULL),
(53, '2018-10-30', '20:10:03', 'Terminado', '20:10:09', '2018-10-30', 4, 14, NULL),
(54, '2018-10-30', '20:10:25', 'Terminado', '20:10:26', '2018-10-30', 4, 1, NULL),
(55, '2018-10-31', '17:33:53', 'Terminado', '17:34:33', '2018-10-31', 4, 2, NULL),
(56, '2018-10-31', '20:04:25', 'Terminado', '20:07:42', '2018-10-31', 4, 16, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  ADD PRIMARY KEY (`Empleado_ID`);

--
-- Indices de la tabla `tbl_incidencia`
--
ALTER TABLE `tbl_incidencia`
  ADD PRIMARY KEY (`Incidencia_ID`);

--
-- Indices de la tabla `tbl_recurso`
--
ALTER TABLE `tbl_recurso`
  ADD PRIMARY KEY (`Recurso_ID`);

--
-- Indices de la tabla `tbl_reserva`
--
ALTER TABLE `tbl_reserva`
  ADD PRIMARY KEY (`Reserva_ID`),
  ADD KEY `fk_reserva_empleado` (`Empleado_ID`),
  ADD KEY `fk_reserva_recurso` (`Recurso_ID`),
  ADD KEY `fk_reserva_incidencia` (`Incidencia_ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  MODIFY `Empleado_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `tbl_incidencia`
--
ALTER TABLE `tbl_incidencia`
  MODIFY `Incidencia_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `tbl_recurso`
--
ALTER TABLE `tbl_recurso`
  MODIFY `Recurso_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `tbl_reserva`
--
ALTER TABLE `tbl_reserva`
  MODIFY `Reserva_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tbl_reserva`
--
ALTER TABLE `tbl_reserva`
  ADD CONSTRAINT `fk_reserva_empleado` FOREIGN KEY (`Empleado_ID`) REFERENCES `tbl_empleado` (`Empleado_ID`),
  ADD CONSTRAINT `fk_reserva_incidencia` FOREIGN KEY (`Incidencia_ID`) REFERENCES `tbl_incidencia` (`Incidencia_ID`),
  ADD CONSTRAINT `fk_reserva_recurso` FOREIGN KEY (`Recurso_ID`) REFERENCES `tbl_recurso` (`Recurso_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
