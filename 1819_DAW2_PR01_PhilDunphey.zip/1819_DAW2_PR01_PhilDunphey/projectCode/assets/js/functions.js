function sendForm (user, pwd) {
    /* Definición de variables eliminando
       los espacios de los bordes. */
       user = user.trim();
       pwd = pwd.trim();

    /* Test para comprobar que realmente el formulario
       envía los campos al JS.

       alert(user);
       alert(pwd); */

       //Creación de variable de mensaje en alert
       let msg = "";

       //Condicional que altera la variable alert si el campo <Nombre> de login.php está vacío.
       if ( user == "" ) {
         msg += "El campo <Usuario> no puede estar vacío\n";
       }

       //Condicional que altera la variable alert si el campo <Contraseña> de login.php está vacío.
       if ( pwd == "" ) {
         msg += "El campo <Contraseña> no puede estar vacío";
       }

       //Condicional que devuelve true si la variable msg ha permancido inalterable.
       //Si se ha alterado, envia un alert() mostrando el mensaje y devuelve false.
       if ( msg == "" ) {
         return true;
       } else {
         alert(msg);
         return false;
       }

}

function validacion(incidencia_nombre, recurso_nombre, incidencia_grado, desc_incidencia) {
    // Definicion de variables recogidas del formulario para insertar incidencias
    incidencia_nombre = incidencia_nombre.trim();
    desc_incidencia = desc_incidencia.trim();

    let msg = "";
    if (incidencia_nombre == "") {
        msg += "[ERROR] El campo <Titulo> debe rellenarse.\n";
    }
     if(incidencia_grado == "") {
        msg += "[ERROR] El campo <Incidencia> debe contener un valor válido.\n";
    }
    if(desc_incidencia == "") {
       msg += "[ERROR] El campo <Descripción> debe rellenarse.\n";
   }

   if ( msg != "" ) {
     alert(msg);
     return false;
   } else {
     return true;
   }


}
