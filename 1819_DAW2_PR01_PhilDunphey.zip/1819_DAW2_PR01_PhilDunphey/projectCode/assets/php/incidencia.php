<?php
	//conectamos a la BD 1819_exemple
	// IP Erix: 172.24.16.253:8080	user: root 	pwd: 1234
	// IP Alex: 172.24.16.236  	user: admin 	pwd: 1234


	// $q = "SELECT * FROM `tbl_empleado`";
	// $q_recursos = mysqli_query($link, $q);

	require "connect.php";
	$c = 'SELECT Empleado_AccessLevel FROM tbl_empleado WHERE Empleado_ID = '. $_REQUEST['user'];
	$consulta= mysqli_query($con,$c);
	 if (mysqli_num_rows($consulta)) {
          while ($userNivel = mysqli_fetch_array($consulta)) {
          	$userLevel = $userNivel['Empleado_AccessLevel'];
		}
	}
	// echo $userLevel ;
	// $userNivel = 'admin';

?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../css/estilos.css">
	<link rel="icon" sizes="16x16" href="./imagenes/favicon.png" type="image/png">
	<title>Reserva de recursos - Phil Dunphy</title>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
	<!-- <script type="text/javascript">
		function redimensionarDiv(texto) {
			if(document.getElementById('registro-incidencia').style.height=='200px'){
				document.getElementById('registro-incidencia').style.height='90px';
				var texto_recortado=texto.substr(0,30);
				document.getElementById('incidencia-descripcion').innerHTML=texto_recortado;
			} else {
				document.getElementById('registro-incidencia').style.height='200px';
				document.getElementById('incidencia-descripcion').innerHTML=texto;
			}
		}
	</script> -->
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
</head>
<body>
		<div class="header">
			<!-- Encabezado de la página -->
			<div class="menu-nav">
				<?php $user = $_REQUEST['user'];
					echo "<a href='reserva.php?user=$user'>"; ?>
					<div id="nav-reserva">
						<p>Reservas</p>
					</div>
				</a>
				<?php $user = $_REQUEST['user'];
					echo "<a href='incidencia.php?user=$user'>"; ?>
					<div id="nav-incidencia" class="nav-activo">
						<p>Incidencias</p>
					</div>
				</a>
			</div>
		</div>
	<div class="content">

		<div class="filtro" id="incidencia-filtro">
			<?php echo "<form action='incidencia.php?user=" . $_REQUEST['user'] . "' method='POST'>"?>
				<div class="titulo-filtro"><h2>BUSCAR: </h2></div>
					<div class="texto-filtro">
						<input type="text" name="nombre-inc"></input>
					</div>

					<div class="tipo-filtro">
						<select name="tipo">
							<option value="">-- Grado --</option>
							<option value="Bajo">Bajo</option>
							<option value="Medio">Medio</option>
							<option value="Critico">Crítico</option>
						</select>
					</div>
					<div class="estado-filtro">
						<select name="estado">
							<option value="">-- Estado --</option>
							<option value="Resuelta">Resuelta</option>
							<option value="En transcurso">En transcurso</option>
						</select>
					</div>
					<div class="submit-filtro">
						<input type="submit" value="Filtrar" name="submit"></input>
					</div>
			</form>
			<div class='historial' id='incidencia'>
							<a href='./incidencia_insert.php?user=$user'>
								<div><!-- <i class="fas fa-plus-circle" style="display: inline-block;"></i> --><p>Nueva Incidencia</p></div>
							</a>
					</div>
		</div>

      <?php

			$where = false;
			$where_code = "";

			if (isset($_POST['nombre-inc']) && $_POST['nombre-inc']!="" ) {
				$where = true;
				$where_code .= " Incidencia_Titulo LIKE '%" . $_POST['nombre-inc'] . "%'";
			}
			if (isset($_POST['tipo']) && $_POST['tipo']!="" ) {
				$where = true;
				if ($where_code == "") {
					$where_code .= " Incidencia_Grado = '" . $_POST['tipo'] . "'";
				} else {
					$where_code .= " AND " . " Incidencia_Grado = '" . $_POST['tipo'] . "'";
				}
			}
			if (isset($_POST['estado']) && $_POST['estado']!="" ) {
				$where = true;
				if ($where_code == "") {
					$where_code .= " Incidencia_Estado = '" . $_POST['estado'] . "'";
				} else {
					$where_code .= " AND " . " Incidencia_Estado = '" . $_POST['estado'] . "'";
				}
			}

			if ($where == false) {
				$q = "SELECT * FROM tbl_incidencia";
			} else {
				$q = "SELECT * FROM tbl_incidencia WHERE $where_code";
			}

      	require "connect.php";
        $query = mysqli_query($con,$q);



        if (mysqli_num_rows($query)) {
          while ($rec = mysqli_fetch_array($query)) {

        $grado_incidencia = utf8_encode($rec['Incidencia_Grado']);
        // echo $grado_incidencia;


            // echo "<div><div class='celda-imagen'><img class='img_recurso' src=".$rec['Recurso_Img']."></div>
            // <div class='celda-nombre'><b>" . utf8_encode($rec['Recurso_Nombre']) . "</b>" . utf8_encode($rec['Recurso_Tipo']) . "</div>
            // <div class='celda-estado'>" . $rec['Recurso_Estado'] . "</div></div>";

              $incidencia = "<div id='registro-incidencia' class='registro-incidencia'>
		            	<div class='celda-i-nombre'>
		            		<div class='incidencia-titulo'>" . utf8_encode($rec['Incidencia_Titulo']) . "</div>";
		      if ($grado_incidencia == "Crítico") {
		       $incidencia .=	"<div class='incidencia-'> nivel " . utf8_encode($rec['Incidencia_Grado']) . " <i class='fas fa-exclamation-circle grado-critico'></i></div>";

		      } elseif ($grado_incidencia == "Medio") {
		      	$incidencia .=	"<div class='incidencia-grado'> nivel " . utf8_encode($rec['Incidencia_Grado']) . " <i class='fas fa-bolt grado-medio'></i></div>";
		      } elseif ($grado_incidencia == "Bajo") {
		      	$incidencia .=	"<div class='incidencia-grado'>nivel Bajo<i class='fas fa-feather-alt grado-bajo'></i></div>";
		      };
		        $incidencia .=  "</div>
		            	<div id='incidencia-descripcion' class='incidencia-descripcion'>"
		            		. substr(utf8_encode($rec['Incidencia_Descripcion']),0,120) . "..." . "
		            	</div>
            		";
		            if ($userLevel == 'admin') {
		       	$incidencia .= "<div class='celda-reserva'>
		       			<a href='detalles_incidencia.php?incId=" . $rec['Incidencia_ID'] ."&user=" . $_REQUEST['user'] . "'><div class='btn_reserva'>Leer más</div></a>
		            	</div>";

		            } else {
		        $incidencia .= "<div class='celda-reserva'></div>";
		        // echo "ERIX CABRÓN";
		            }

		       $incidencia .= "</div>";
            echo $incidencia;

          }
        }
      ?>
	</div>
</body>
</html>
