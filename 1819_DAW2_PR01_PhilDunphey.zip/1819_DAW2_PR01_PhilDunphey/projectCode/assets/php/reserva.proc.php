<!--
Proc de inserción de reserva.

Autor: Erix Mamani Villacresis
Última modificación: 31/10/2018

-->

<?php
    // Archivo variables de conexión a la base de datos
    require "connect.php";

    // Recogida de datos enviados por el formulario en reserva.php
    $user = $_POST['user'];
    $rec_ID = $_POST['recurso_id'];

    // Query de inserción de datos para la Reserva
    $q = "INSERT INTO tbl_reserva (Reserva_FechaRec, Reserva_HoraRec, Empleado_ID, Recurso_ID,Reserva_Estado) VALUES (
         CURDATE(), CURTIME(), $user, $rec_ID,'En uso' );";
    // Query de update del estado de la tabla recurso
    $q2 = "UPDATE tbl_recurso SET Recurso_Estado = 'En uso' WHERE Recurso_ID = $rec_ID";

    // Ejecución de queries
    mysqli_query($con, $q);
    mysqli_query($con, $q2);

    //Redirección a reserva.php
    header("Location: reserva.php?user=" . $user);

?>
