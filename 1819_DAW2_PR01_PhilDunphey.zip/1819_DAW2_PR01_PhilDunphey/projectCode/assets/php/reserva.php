<!--
Página de vista de recursos y solicitud de reserva / devolución.

Autores: Joel Moreno Hidalgo y Erix Mamani Villacresis
Última modificación: 31/10/2018

-->

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/estilos.css">
		<link rel="icon" sizes="16x16" href="./imagenes/favicon.png" type="image/png">
		<meta charset="utf-8">
		<title>Reserva de recursos - Phil Dunphy</title>
		<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	</head>

	<body>

		<!-- Encabezado de la página y creación de pestañas -->
		<div class="header">

			<div class="menu-nav">


				<!-- Pestaña de Reserva -->
				<?php $user = $_REQUEST['user'];
					echo "<a href='reserva.php?user=$user'>"; ?>
					<div id="nav-reserva" class="nav-activo"><p>Reservas</p></div>
				</a>

				<!-- Pestaña de Incidencias -->
				<?php $user = $_REQUEST['user'];
					echo "<a href='incidencia.php?user=$user'>"; ?>
					<div id="nav-incidencia"><p>Incidencias</p></div>
				</a>
			</div>

		</div> <!-- Fin de div header -->

		<div class="content">
			<!-- Mensaje de bienvenida-->
			<center><h2>
				<?php require "connect.php";
				$q = "SELECT * FROM tbl_empleado WHERE Empleado_ID = " . $_REQUEST['user'];
				$user = $_REQUEST['user'];
				$query = mysqli_query($con, $q);
				while ($i = mysqli_fetch_array($query)) {
					echo "Bienvenido, $i[Empleado_Nombre]";
					$userLevel = $i['Empleado_AccessLevel'];
				} ?>
			</h2></center>

			<br>

		<!-- Filtro de búsqueda -->
			<div class="filtro">

				<form action='reserva.php' method='POST'>

					<!-- Envío oculto del ID del usuario -->
					<?php echo "<input type='hidden' name='user' value='$user'></input>"?>

					<div class="titulo-filtro"><h2>BUSCAR: </h2></div>
					<!-- Input de búsqueda por palabra -->
					<div class="texto-filtro"><input type="text" name="nombre_recurso"></input></div>

					<!-- Select que filtra por tipo de recurso -->
					<div class="tipo-filtro">
						<select name="tipo">
							<option value="">- Tipo -</option>
							<option value="Sala">Sala</option>
							<option value="Material">Material</option>
						</select>
					</div>

					<!-- Select que filtra por estado de recurso -->
					<div class="estado-filtro">
						<select name="estado">
							<option value="">-- Estado --</option>
							<option value="Disponible">Disponible</option>
							<option value="En uso">En uso</option>
						</select>
					</div>

					<!-- Botón de submit del formulario -->
					<div class="submit-filtro">
						<input type="submit" value="Filtrar" name="submit"></input>
					</div>

				</form>
			<?php
			if ($userLevel == 'admin') {
				echo "<div class='historial'>
							<a href='./historial.php?user=$user'>
								<div>Historial</div>
							</a>
					</div>";
			} ?>

			</div>
		<!-- Fin de filtro -->

		<!-- Variación de query de muestra de recursos según el filtro -->
      <?php
				//Archivo variables de conexión a la base de datos
      	require "connect.php";

				// Variables de filtro.
				// $where: variable boleana con valor false por defecto. Si hay algún valor de filtrado, cambia a true.
				// $_where_code: variable string que contendrá las condiciones de filtrado en SQL, si existen. Vacía por defecto.
				$where = false;
				$where_code = "";

				//Condicionales de filtrado:
				//Si el filtro envía variables con contenido, dependiendo del contenido (nombre, tipo o estado),
				//$where cambia a true y $where_code se llena con el contenido que tiene que llevar el WHERE
				//de la query SQL de visualización de recursos (más adelante).

				//Condicional de filtrado por nombre.
				if (isset($_POST['nombre_recurso']) && $_POST['nombre_recurso'] != "") {
					$where = true;
					$where_code .= "Recurso_Nombre LIKE '%" . $_POST['nombre_recurso'] . "%'";
				}

				//Condicional de filtrado por tipo.
				if (isset($_POST['tipo']) && $_POST['tipo']!= "" ) {
					if ($where_code == "") { //Condicional de control de posición en condición en la sentencia WHERE
						$where_code .= "Recurso_Tipo = '" . $_POST['tipo'] . "'";
					} else {
						$where_code .= " AND " . "Recurso_Tipo = '" . $_POST['tipo'] . "'";
					}
					$where = true;
				}

				//Condicional de filtrado por estado.
				if (isset($_POST['estado']) && $_POST['estado']!="" ) {
					if ($where_code == "") { //Condicional de control de posición en condición en la sentencia WHERE
						$where_code .= "Recurso_Estado = '" . $_POST['estado'] . "'";
					} else {
						$where_code .= " AND " . "Recurso_Estado = '" . $_POST['estado']. "'";
					}
					$where = true;
				}

				// Condicional de creación de query de visualización de recursos.
				// Si $where contiene valor false, la query contendrá los datos de todos los recursos.
				// En caso contrario, se rellena el WHERE de la query con el contenido de $where_code.
				if ($where == false) {
					$q = "SELECT * FROM tbl_recurso";
				} else {
					$q = "SELECT * FROM tbl_recurso WHERE $where_code";
				}

				// Cambio a utf-8.
				// Alternativa: mysqli_query($con,"SET NAMES 'utf8'"); en este caso hace falta quitar los encodes y decodes del código.
				$q = utf8_decode($q);
        $query = mysqli_query($con,$q);

				// Muestra de recursos.
				// Primero, con el primer condicional se comprueba que hay recursos que mostrar (pueden no haber a causa de un mal filtrado por parte del usuario).
				// Con el While... se muestran tantos recursos como registros haya recogido la query.
				// Hay tres tipos de visualización de recurso:
				// 1: Si el recurso está disponible. Se activa el botón de Reservar (Condicional line 159)
				// 2: Si el recurso está en uso por usuario que se ha logueado. Se activa la opción de Liberar. (Condicional line )
				// 3: Si el recurso está en uso por un usuario diferente al logueado. Sin botón de Reservar no Liberar. (Condicional line )

        if (mysqli_num_rows($query)>0) { //Comprobación de recursos a mostrar
          while ($rec = mysqli_fetch_array($query)) { //Muestra de datos de los recursos en formato array

            if ($rec['Recurso_Estado']=="Disponible") { //Recurso disponible

              echo "<div class='registro-recurso si_reserva'>
		              		<div class='celda-imagen'>
		              			<img class='img_recurso' src=" . $rec['Recurso_Img'] . ">
		              		</div>
		            			<div class='celda-nombre'>
		            				<div class='nombre-titulo'>" . utf8_encode($rec['Recurso_Nombre']) . "</div>
		            				<div class='nombre-tipoderecurso'>" . utf8_encode($rec['Recurso_Tipo']) . "</div>
		            			</div>
		            			<div class='celda-estado celda-estado-positivo'>" . $rec['Recurso_Estado'] . "</div>
		            			<div class='celda-reserva'>
			            			<form action='reserva.proc.php' method='POST'>
			            				<input type='submit' class='btn_reserva' value='Reservar' name='btn_reservar'></input>
			            				<input type='hidden' name='user' value='" . $_REQUEST['user'] . "'></input>
			            				<input type='hidden' name='recurso_id' value='" . $rec['Recurso_ID'] . "'></input>
			            			</form>
		            			</div>
            				</div>";

            } else if ( $rec['Recurso_Estado'] == "En uso" ) { //Recurso en uso.

							// Query para comprobar si el usuario logueado es quien está usando o no el recurso.
							$q2 = "SELECT * FROM tbl_reserva WHERE Empleado_ID = " . $_REQUEST['user'] . " AND Reserva_Estado ='En uso' AND Recurso_ID = " . $rec['Recurso_ID'] ."";
							$query2 = mysqli_query($con,$q2);


							if (mysqli_num_rows($query2)>0) { // El usuario logueado es quien ha reservado el recurso.
								while ($j = mysqli_fetch_array($query2)) {

									echo "
			              <div class='registro-recurso no_reserva'>
			              		<div class='celda-imagen'>
			              			<img class='img_recurso' src=".$rec['Recurso_Img'].">
			              		</div>
			            			<div class='celda-nombre'>
			            				<div class='nombre-titulo'>" . utf8_encode($rec['Recurso_Nombre']) . "</div>
			            				<div class='nombre-tipoderecurso'>" . utf8_encode($rec['Recurso_Tipo']) . "</div>
			            			</div>
			   		        		<div class='celda-estado celda-estado-negativo'>" . $rec['Recurso_Estado'] . "</div>
			   		        		<div class='celda-reserva'>
													<form action='liberar.proc.php' method='POST'>
														<input type='submit' class='btn_reserva' value='Liberar' name='btn_reservar'></input>
														<input type='hidden' name='user' value='" . $_REQUEST['user'] . "'></input>
														<input type='hidden' name='recurso_id' value='" . $rec['Recurso_ID'] . "'></input>
													</form>
			   		        		</div>
			   		    			</div>";
								}
							} else { // El usuario logueado no es quien ha reservado el recurso.

									echo "
			              <div class='registro-recurso no_reserva'>
			              	<div class='celda-imagen'>
			              		<img class='img_recurso' src=".$rec['Recurso_Img'].">
			              	</div>
			            		<div class='celda-nombre'>
			            			<div class='nombre-titulo'>" . utf8_encode($rec['Recurso_Nombre']) . "</div>
			            			<div class='nombre-tipoderecurso'>" . utf8_encode($rec['Recurso_Tipo']) . "</div>
			            		</div>
			   		        	<div class='celda-estado celda-estado-negativo'>" . $rec['Recurso_Estado'] . "</div>
			   		        	<div class='celda-reserva'>
			   		        		<form action='reserva.proc.php' method='POST' onsubmit='return false'>
			   		        			<input type='submit' class='btn_reserva_NA' value='Reservar' name='btn_reservar'></input>
												</form>
			   		        	</div>
			   		    		</div>";

							} // Fin else de condicional sobre si el usuario logueado es o no quien ha reservado el recurso -> if (mysqli_num_rows($query2)>0) <-

            } //Fin del condicional sobre si el estado del recurso es "En uso" -> else if ( $rec['Recurso_Estado'] == "En uso" ) <-

          } //Fin del While... de muestra de recursos. -> while ($rec = mysqli_fetch_array($query)) <-

        } else { // En caso de no haber ningún recurso para mostrar.
        	echo "<center><h3>No hay resultados</h3></center>";
        } // Fin condicional de muestra de recursos

      ?>
	</div>
</body>
</html>
