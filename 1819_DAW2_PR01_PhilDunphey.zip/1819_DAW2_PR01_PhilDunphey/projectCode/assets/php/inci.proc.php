<?php
  require "connect.php";

  // Recogemos los datos del formulario insertar_incidencia
  $issue_name = $_POST['incidencia_nombre'];
  $resource_name = $_POST['recurso_nombre'];
  $issue_grade = $_POST['incidencia_grado'];
  $issue_desc = $_POST['desc_incidencia'];
  $user = $_REQUEST['user'];


  // Creamos las queries de inserción de datos y las giadamos en variables
  $q_data_issue = "INSERT INTO tbl_incidencia (Incidencia_Titulo, Incidencia_Descripcion, Incidencia_Grado,Incidencia_Estado) VALUES ('$issue_name', '$issue_desc', '$issue_grade', 'En transcurso')";

  // Ejecutamos las queries
  $query_issue = mysqli_query($con, $q_data_issue);

  // Reditigimos al usuario a la página incidencias
  header("Location: incidencia.php?user= $user");
?>
