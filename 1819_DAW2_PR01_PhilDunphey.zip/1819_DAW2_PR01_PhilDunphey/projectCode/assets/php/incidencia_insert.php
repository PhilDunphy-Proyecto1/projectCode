<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form Incidencia</title>
    <link rel="stylesheet" href="../css/issue_form.css">
    <script src="../js/functions.js"></script>
    <style>
        body{
            background-image: url("../img/bg_issue_form.jpeg");
        }
    </style>
</head>

<body>
    <form action="inci.proc.php"  method="POST" onsubmit="return validacion(incidencia_nombre.value,recurso_nombre.value,incidencia_grado.value,desc_incidencia.value)">
        <h2>Insertar Incidencia</h2>
        <input type="text" id="nombre_inc" name="incidencia_nombre" placeholder=" Título de la incidencia"></input>
        <select name="recurso_nombre">
            <?php
                require "connect.php";
                $q = "SELECT * FROM tbl_recurso";
                $query = mysqli_query($con, $q);
                while ($i = mysqli_fetch_array($query)) {
                    echo "<option value='" . $i['Recurso_ID'] . "'>" . utf8_encode($i['Recurso_Nombre']) . "</option>";
                }
            ?>
        </select>
        <select name="incidencia_grado">
            <option value="">-- Grado de Incidencia --</option>
            <option value="Bajo">Bajo</option>
            <option value="Medio">Medio</option>
            <option value="Crítico">Crítico</option>
        </select>
        <?php
            echo "<input type='hidden' name='user' value='4'>";
        ?>
        <textarea id="desc" name="desc_incidencia" cols="30" rows="10" placeholder="Descripción..."></textarea>
        <input id="btn" type="submit" name="enviar"></input>

    </form>
</body>

</html>
