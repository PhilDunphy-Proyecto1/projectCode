<!--
Página proc de redirección dependiendo de la validez del usuario y de su contraseña en la base de batos.

Autor: Erix Mamani Villacresis
Última modificación: 31/10/2018

-->
<?php
  // Carga del php con las variables de conexión a la base de datos.
  require "connect.php";

  // Alojamiento de las variables enviadas por login.php en variables locales del archivo
  $user = $_POST['user'];
  $pwd = $_POST['pwd'];

  // Creación de query
  $q = "SELECT * FROM tbl_empleado WHERE Empleado_UserName = '$user' AND Empleado_Password = '$pwd'";
  $query = mysqli_query($con,$q);

  // Condicional de redirección.
  // Si los datos enviados coinciden con un registro de usuario de la base de datos, redirige a reserva.php enviando la ID de usuario.
  // En caso de no coincidir, volverá a login.php enviando una variable que activa un mensaje de error.
  if (mysqli_num_rows($query)>0) {
    while ($i = mysqli_fetch_array($query)) {
      header("Location: reserva.php?user=" . $i['Empleado_ID']);
    }
  } else {
    header("Location: login.php?er");
  }
?>
