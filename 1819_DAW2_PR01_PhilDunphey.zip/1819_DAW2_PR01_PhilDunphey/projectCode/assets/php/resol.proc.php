<!-- Hecho por Erix Mamani Villacresis -->

<?php
  require "connect.php";
  $q = "UPDATE tbl_incidencia SET Incidencia_Estado = 'Resuelta' WHERE Incidencia_ID = " . $_REQUEST['id'];
  mysqli_query($con,$q);
  header("Location: incidencia.php?user=" . $_REQUEST['user']);
?>
