<!--
Página de login de ususario.

Autores: Alejandro Reñones Farré y Erix Mamani Villacresis
Última modificación: 31/10/2018

-->
<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Formulario SingIn</title>
      <link rel="stylesheet" href="../css/login_form.css">
      <script src="../js/functions.js"></script>
  </head>

  <body>
    <!--  Formulario de acceso que pide las credenciales de los usuarios que quieran entrar.

          Al realizar el submit, el usuario y contraseña introducidos van a una función de javascript
          que mira si alguna de las dos está vacía o si únicamente contiene espacios en blanco.

          En caso de ser así, muestra un mensaje de aviso y detiene el envio del formulario. -->
    <form class="box" action="login.proc.php" method="post" onsubmit="return sendForm(user.value,pwd.value);">
        <h1>Login</h1>
        <input type="text" id="user" name="user" placeholder="Usuario">
        <input type="password" id="pwd" name="pwd" placeholder="Contraseña">
        <input type="submit" value="Login">
        <!-- Mensaje de error que se muestra en caso de que las credenciales enviadas no coinciden con el registro de ningún usuario en la base de datos -->
        <?php
        if(isset($_GET['er'])) {
          echo "<span class='err_msg'>El nombre de usuario o la contraseña son incorrectos.</span>";
        }
        ?>
    </form>

  </body>

</html>
