<!--
Página de vista de recursos y solicitud de reserva / devolución.

Autores: Joel Moreno Hidalgo y Erix Mamani Villacresis
Última modificación: 31/10/2018

-->

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/estilos.css">
		<link rel="icon" sizes="16x16" href="./imagenes/favicon.png" type="image/png">
		<meta charset="utf-8">
		<title>Reserva de recursos - Phil Dunphy</title>
		<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	</head>

	<body>

		<!-- Encabezado de la página y creación de pestañas -->
		<div class="header">

			<div class="menu-nav">


				<!-- Pestaña de Reserva -->
				<?php $user = $_REQUEST['user']; echo "<a href='reserva.php?user=$user'>"; ?>
					<div id="nav-reserva"><p>Reservas</p></div>
				</a>

				<!-- Pestaña de Incidencias -->
				<?php $user = $_REQUEST['user']; echo "<a href='incidencia.php?user=$user'>"; ?>
					<div id="nav-incidencia"><p>Incidencias</p></div>
				</a>
			</div>

		</div> <!-- Fin de div header -->

		<div class="content">
			<!-- Mensaje de bienvenida-->
			<center><h2>
				<?php require "connect.php";
				//$q = "SELECT * FROM tbl_empleado WHERE Empleado_ID = " . $_REQUEST['user'];
				$user = $_REQUEST['user'];
				//$query = mysqli_query($con, $q);
				//while ($i = mysqli_fetch_array($query)) {
				//	echo "Bienvenido, $i[Empleado_Nombre]";
				//} ?>
				Historial de reservas
			</h2></center>

			<br>

		<!-- Filtro de búsqueda -->
			<center><div class="filtro">

				<form action='historial.php' method='POST'>

					<!-- Envío oculto del ID del usuario -->
					<?php echo "<input type='hidden' name='user' value='$user'></input>"?>

					<div class="tituloF1-filtro"><h2>Fecha de recogida: </h2></div>
					<!-- Input de búsqueda por palabra -->
					<!--<div class="texto-filtro"><input type="text" name="nombre_recurso"></input></div>
-->
					<div class="titulo2-filtro"><h2>Día: </h2></div>
					<!-- Select que filtra por tipo de recurso -->
					<div class="dia-filtro">
						<select name="dia1">
							<option value=0>--</option>
							<?php
								for ($i=1; $i<=31 ; $i++) {
									echo "<option value='$i'>$i</option>";
								}
							?>
						</select>
					</div>
					<div class="titulo2-filtro"><h2>Mes: </h2></div>
					<!-- Select que filtra por tipo de recurso -->
					<div class="mes-filtro">
						<select name="mes1">
							<option value=0>--</option>
							<?php
								for ($i=1; $i<=12 ; $i++) {
									echo "<option value='$i'>$i</option>";
								}
							?>
						</select>
					</div>
					<div class="titulo2-filtro"><h2>Año: </h2></div>
					<!-- Select que filtra por tipo de recurso -->
					<div class="anno-filtro">
						<select name="anno1">
							<option value=0>----</option>
							<?php
								for ($i=2010; $i<=2018 ; $i++) {
									echo "<option value='$i'>$i</option>";
								}
							?>
						</select>
					</div>

					<br>

					<div class="tituloF1-filtro"><h2>Fecha de devolución: </h2></div>
					<div class="titulo2-filtro"><h2>Día: </h2></div>
					<!-- Select que filtra por tipo de recurso -->
					<div class="dia-filtro">
						<select name="dia2">
							<option value=0>--</option>
							<?php
								for ($i=1; $i<=31 ; $i++) {
									echo "<option value='$i'>$i</option>";
								}
							?>
						</select>
					</div>
					<div class="titulo2-filtro"><h2>Mes: </h2></div>
					<!-- Select que filtra por tipo de recurso -->
					<div class="mes-filtro">
						<select name="mes2">
							<option value=0>--</option>
							<?php
								for ($i=1; $i<=12 ; $i++) {
									echo "<option value='$i'>$i</option>";
								}
							?>
						</select>
					</div>
					<div class="titulo2-filtro"><h2>Año: </h2></div>
					<!-- Select que filtra por tipo de recurso -->
					<div class="anno-filtro">
						<select name="anno2">
							<option value=0>----</option>
							<?php
								for ($i=2010; $i<=2018 ; $i++) {
									echo "<option value='$i'>$i</option>";
								}
							?>
						</select>
					</div>

					<br>

					<div class="tituloF1-filtro"><h2>Recurso: </h2></div>
					<div class="estado-filtro">
						<select name="recurso">
							<option value=0>-- Recurso --</option>
							<?php
							require "connect.php";
							$q = "SELECT * FROM tbl_recurso";
							$query = mysqli_query($con,$q);
							while ($i = mysqli_fetch_array($query)) {
								echo "<option value='" . $i['Recurso_ID'] . "'>" . utf8_encode($i['Recurso_Nombre']) . "</input>";
							}
							?>
						</select>
					</div>
					<div class="tituloF1-filtro"><h2>Estado: </h2></div>
					<!-- Select que filtra por estado de recurso -->
					<div class="estado-filtro">
						<select name="estado">
							<option value="">- Estado -</option>
							<option value="Terminado">Terminado</option>
							<option value="En uso">En uso</option>
						</select>
					</div>

					<!-- Botón de submit del formulario -->
					<div class="submit-filtro">
						<input type="submit" name="submit"></input>
					</div>

				</form>

			</div></center>
		<!-- Fin de filtro -->

		<!-- Variación de query de muestra de recursos según el filtro -->
      <?php
				//Archivo variables de conexión a la base de datos
      	require "connect.php";

				// Variables de filtro.
				// $where: variable boleana con valor false por defecto. Si hay algún valor de filtrado, cambia a true.
				// $_where_code: variable string que contendrá las condiciones de filtrado en SQL, si existen. Vacía por defecto.
				$where = false;
				$where_code = "";

				//Condicionales de filtrado:
				//Si el filtro envía variables con contenido, dependiendo del contenido (nombre, tipo o estado),
				//$where cambia a true y $where_code se llena con el contenido que tiene que llevar el WHERE
				//de la query SQL de visualización de recursos (más adelante).

				//Condicional de filtrado por nombre.
				if (isset($_POST['dia1']) && $_POST['dia1']!=0 ) {
					$where = true;
					$where_code .= " DAY(Reserva_FechaRec) = " . $_POST['dia1'];
				}
				if (isset($_POST['mes1']) && $_POST['mes1']!=0 ) {
					$where = true;
					if ($where_code == "") {
						$where_code .= " MONTH(Reserva_FechaRec) = " . $_POST['mes1'];
					} else {
						$where_code .= " AND " . " MONTH(Reserva_FechaRec) = " . $_POST['mes1'];
					}
				}
				if (isset($_POST['anno1']) && $_POST['anno1']!=0 ) {
					$where = true;
					if ($where_code == "") {
						$where_code .= " YEAR(Reserva_FechaRec) = " . $_POST['anno1'];
					} else {
						$where_code .= " AND " . " YEAR(Reserva_FechaRec) = " . $_POST['anno1'];
					}
				}

				if (isset($_POST['dia2']) && $_POST['dia2']!=0 ) {
					$where = true;
					if ($where_code == "") {
						$where_code .= " DAY(Reserva_FechaDev) = " . $_POST['dia2'];
					} else {
						$where_code .= " AND " . " DAY(Reserva_FechaDev) = " . $_POST['dia2'];
					}
				}
				if (isset($_POST['mes2']) && $_POST['mes2']!=0 ) {
					$where = true;
					if ($where_code == "") {
						$where_code .= " MONTH(Reserva_FechaDev) = " . $_POST['mes2'];
					} else {
						$where_code .= " AND " . " MONTH(Reserva_FechaDev) = " . $_POST['mes2'];
					}
				}
				if (isset($_POST['anno2']) && $_POST['anno2']!=0 ) {
					$where = true;
					if ($where_code == "") {
						$where_code .= " YEAR(Reserva_FechaDev) = " . $_POST['anno2'];
					} else {
						$where_code .= " AND " . " YEAR(Reserva_FechaDev) = " . $_POST['anno2'];
					}
				}

				//Condicional de filtrado por tipo.
				if (isset($_POST['recurso']) && $_POST['recurso']!= "0" ) {
					if ($where_code == "") { //Condicional de control de posición en condición en la sentencia WHERE
						$where_code .= " Recurso_ID = '" . $_POST['recurso'] . "'";
					} else {
						$where_code .= " AND " . " Recurso_ID = '" . $_POST['recurso'] . "'";
					}
					$where = true;
				}

				//Condicional de filtrado por estado.
				if (isset($_POST['estado']) && $_POST['estado']!="" ) {
					if ($where_code == "") { //Condicional de control de posición en condición en la sentencia WHERE
						$where_code .= "Reserva_Estado = '" . $_POST['estado'] . "'";
					} else {
						$where_code .= " AND " . "Reserva_Estado = '" . $_POST['estado']. "'";
					}
					$where = true;
				}

				// Condicional de creación de query de visualización de recursos.
				// Si $where contiene valor false, la query contendrá los datos de todos los recursos.
				// En caso contrario, se rellena el WHERE de la query con el contenido de $where_code.
				if ($where == false) {
					$q = "SELECT * FROM tbl_reserva";
				} else {
					$q = "SELECT * FROM tbl_reserva WHERE $where_code";
				}

				// Cambio a utf-8.
				// Alternativa: mysqli_query($con,"SET NAMES 'utf8'"); en este caso hace falta quitar los encodes y decodes del código.
				$q = utf8_decode($q);
        $query = mysqli_query($con,$q);

				// Muestra de recursos.
				// Primero, con el primer condicional se comprueba que hay recursos que mostrar (pueden no haber a causa de un mal filtrado por parte del usuario).
				// Con el While... se muestran tantos recursos como registros haya recogido la query.
				// Hay tres tipos de visualización de recurso:
				// 1: Si el recurso está disponible. Se activa el botón de Reservar (Condicional line 159)
				// 2: Si el recurso está en uso por usuario que se ha logueado. Se activa la opción de Liberar. (Condicional line )
				// 3: Si el recurso está en uso por un usuario diferente al logueado. Sin botón de Reservar no Liberar. (Condicional line )

        if (mysqli_num_rows($query)>0) { //Comprobación de recursos a mostrar
          while ($rec = mysqli_fetch_array($query)) { //Muestra de datos de los recursos en formato array
						$q2 = "SELECT tbl_recurso.*,DATE_FORMAT(tbl_reserva.Reserva_FechaRec,'%e de %M, %Y') AS Rec, DATE_FORMAT(tbl_reserva.Reserva_FechaDev,'%e de %M, %Y') AS Dev,
						TIME_FORMAT(tbl_reserva.Reserva_HoraRec,'%H:%i') AS RecH, TIME_FORMAT(tbl_reserva.Reserva_HoraDev,'%H:%i') AS DevH, tbl_empleado.Empleado_Nombre FROM tbl_recurso INNER JOIN tbl_reserva ON tbl_recurso.Recurso_ID = tbl_reserva.Recurso_ID INNER JOIN tbl_empleado ON tbl_reserva.Empleado_ID=tbl_empleado.Empleado_ID WHERE tbl_recurso.Recurso_ID = " . $rec['Recurso_ID'];
						$query2 = mysqli_query($con,$q2);
						mysqli_query($con,"SET lc_time_names = 'es_ES'");

							while ($k = mysqli_fetch_array($query2)) {
								echo "<div class='registro-recurso si_reserva'>
			              		<div class='celda-imagen'>
													<img class='img_recurso' src=" . $k['Recurso_Img'] . ">
			              		</div>
			            			<div class='celda-nombre_inc'>
			            				<div class='nombre-titulo'>" . utf8_encode($k['Recurso_Nombre']) . "</div>
			            				<div class='nombre-tipoderecurso'>" . utf8_encode($k['Recurso_Tipo']) . "</div>
			            			</div>
												<div class='celda-estado_inc '>Persona: " . $k['Empleado_Nombre'] . "</div>
			            			<div class='celda-estado_inc celda-estado-positivo'>Recogido: " . $k['Rec'] . " - " . $k['RecH'] . "</div>
												<div class='celda-estado_inc celda-estado-negativo'>Devuelto: " . $k['Dev'] . " - " . $k['DevH'] . "</div>


	            				</div>";
							}
					}
				} else {
					echo "No hay resultados";
				}
			 ?>
	</div>
</body>
</html>
